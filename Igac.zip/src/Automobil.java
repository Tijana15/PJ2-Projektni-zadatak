import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Random;

public class Automobil extends Vozilo implements AutomobilInterface {
    public static final int MAX_BROJ_PUTNIKA=5;
    public Automobil()
    {
        super(new Random().nextInt(MAX_BROJ_PUTNIKA)+1);

    };

}
