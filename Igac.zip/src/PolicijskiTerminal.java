import java.util.logging.Level;
import java.util.logging.Logger;

public class PolicijskiTerminal extends Terminal
{
    @Override
    public void obradaVozila(Vozilo vozilo)
    {
        int vrijemeObradePutnika;
        if(vozilo instanceof AutobusInterface)
        {
            vrijemeObradePutnika=100;
        }
        else
        {
            vrijemeObradePutnika=500;
        }
        for(int i=0; i<vozilo.getPutnici().size();i++)
        {
            try
            {
                Thread.sleep(vrijemeObradePutnika);
            }catch(InterruptedException e)
            {
                Logger.getLogger(Simulacija.class.getName()).log(Level.WARNING, e.fillInStackTrace().toString());
            }
            if (!vozilo.getPutnici().get(i).getIdentifikacioniDokument().isIspravan())
            {
                System.out.println("Putnik "+vozilo.getPutnici().get(i).getIdentifikacioniDokument()+" ne moze preci granicu zbog neispravnosti identifikacionog dokumenta.");
                System.out.println("Zbog neispravnosti dokumenta, "+vozilo.getPutnici().get(i)+" se izbacuje iz vozila.");
                vozilo.getPutnici().remove(vozilo.getPutnici().get(i));
            }
            else
            {
                System.out.println("Putnik "+vozilo.getPutnici().get(i).getIdentifikacioniDokument()+" prosao policijsku provjeru.");
            }
        }
        try
        {
            Thread.sleep(vrijemeObradePutnika);
        }catch(InterruptedException e)
        {
            Logger.getLogger(Simulacija.class.getName()).log(Level.WARNING, e.fillInStackTrace().toString());
        }
        if(!vozilo.getVozac().getIdentifikacioniDokument().isIspravan())
        {
            System.out.println(vozilo+" ne moze preci granicu zbog neispravnosti dokumenta vozaca "+vozilo.getVozac());
            vozilo.setPaoPolicijski(true);
        }
        else
        {
            System.out.println(vozilo+" uspješno prošao policijski terminal.");
            vozilo.setPaoPolicijski(false);
        }
    }
}
