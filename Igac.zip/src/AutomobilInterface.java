public interface AutomobilInterface{
}
