import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Logger;

public class Simulacija {
    public static ArrayList<Vozilo> granicniRed=new ArrayList<Vozilo>(50);
    //final static int BROJ_AUTOBUSA=5;
    //final static int  BROJ_AUTA=35;
    final static int BROJ_KAMIONA=10;
    public static Handler handler;
    {
        try {
            // ime logger-a je naziv klase
            handler = new FileHandler("Dejo.log");
            Logger.getLogger(Simulacija.class.getName()).addHandler(handler);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static CarinskiTerminal carinskiTerminalZaKamione=new CarinskiTerminal();
    //public static CarinskiTerminal carinskiTerminal=new CarinskiTerminal();

    public static PolicijskiTerminal policijskiTerminalZaKamione=new PolicijskiTerminal();
    //public static PolicijskiTerminal policijskiTerminal1=new PolicijskiTerminal();
    //public static PolicijskiTerminal policijskiTerminal2=new PolicijskiTerminal();

    public static void main(String[] args){

        for(int i=0;i<BROJ_KAMIONA;i++)
        {
            granicniRed.add(new Kamion());
        }
        for(int j=0; j<granicniRed.size();j++)
        {
            granicniRed.get(j).start();
        }


    }

}