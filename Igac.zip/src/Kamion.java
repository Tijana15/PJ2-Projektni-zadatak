import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Kamion extends Vozilo implements KamionInterface
{
    private Teret teret;
    private boolean potrebnaCarinskaDokumentacija;
    private double deklarisanaMasaTereta;
    private boolean kamionImaVeciTeret;
    private static int globalniBrojacKamiona=0;
    public Kamion()
    {
        super(new Random().nextInt(2)+1);
        globalniBrojacKamiona++;
        deklarisanaMasaTereta=new Random().nextDouble(1000);
        teret=new Teret(deklarisanaMasaTereta);
        potrebnaCarinskaDokumentacija=new Random().nextBoolean();
        kamionImaVeciTeret=new Random().nextInt(100)<20;
        if(kamionImaVeciTeret)
        {
            teret.setStvarnaMasaTereta(deklarisanaMasaTereta+new Random().nextDouble(31)*deklarisanaMasaTereta);
        }
    }
    public Teret getTeret() {
        return teret;
    }

    public double getDeklarisanaMasaTereta() {
        return deklarisanaMasaTereta;
    }

    public boolean daLiJePotrebnaCarinskaDokumentacija() {
        return potrebnaCarinskaDokumentacija;
    }

    public boolean daLiKamionImaVeciTeret() {
        return kamionImaVeciTeret;
    }
    public void run()
    {
        boolean prosaoPolicijskiTerminal = false;

        while (!prosaoPolicijskiTerminal){
            if (Simulacija.granicniRed.size() != 0 && Simulacija.granicniRed.get(0) == this &&
                    Simulacija.policijskiTerminalZaKamione.jeSlobodan()) {
                Simulacija.policijskiTerminalZaKamione.setSlobodan(false);
                System.out.println(this + " je zauzeo policijski terminal.");
                Simulacija.granicniRed.remove(0);
                System.out.println(this + " je uklonjeno iz granicnog reda.");
                System.out.println("Obrada " + this + " na policijskom:");
                Simulacija.policijskiTerminalZaKamione.obradaVozila(this);
                if (paoPolicijski) {
                    System.out.println("Pošto je kamion "+this+" pao policijsku kontrolu, oslobađa se policijski terminal.");

                    //TODO dodati logiku kad padne policijski
                    String imeFajla = "java.txt";
                    try {
                        FileWriter fileWriter = new FileWriter(imeFajla);
                        BufferedWriter writer = new BufferedWriter(fileWriter);
                        String tekstZaUpis = "Ovo je neki tekst za kamion" +this+" koji nije prosao provjeru";
                        writer.write(tekstZaUpis);
                        writer.close();
                        fileWriter.close();
                    } catch (IOException e) {
                        Logger.getLogger(Simulacija.class.getName()).log(Level.WARNING, e.fillInStackTrace().toString());
                    }
                    Simulacija.policijskiTerminalZaKamione.setSlobodan(true);
                }
                prosaoPolicijskiTerminal=true;
            }
        }
        boolean prosaoCarinskiTerminal = false;
        if (!paoPolicijski) {
            while (!prosaoCarinskiTerminal) {
                if (Simulacija.carinskiTerminalZaKamione.jeSlobodan()) {
                    Simulacija.carinskiTerminalZaKamione.setSlobodan(false);
                    System.out.println(this + " je zauzeo carinski terminal");
                    System.out.println(this + " oslobađa iza sebe policijski terminal.");
                    Simulacija.policijskiTerminalZaKamione.setSlobodan(true);
                    System.out.println("Obrada vozila " + this + " na carinskom terminalu:");
                    Simulacija.carinskiTerminalZaKamione.obradaVozila(this);
                    if (jePaoCarinski()) {
                        System.out.println("Kamion "+this+" je pao na carinskoj kontroli. Oslobađamo carinski terminal za dalja vozila.");

                        //TODO dodati logiku kad padne carinski
                        String imeFajla = "java1.txt";
                        try {
                            FileWriter fileWriter = new FileWriter(imeFajla);
                            BufferedWriter writer = new BufferedWriter(fileWriter);
                            String tekstZaUpis = "Ovo je neki tekst za kamion koji nije prosao carinsku provjeru";
                            writer.write(tekstZaUpis);
                            writer.close();
                            fileWriter.close();
                        } catch (IOException e) {
                            Logger.getLogger(Simulacija.class.getName()).log(Level.WARNING, e.fillInStackTrace().toString());
                        }
                    } else
                    {
                        System.out.println("Kamion "+this+" je presao carinu. Slijedi oslobađanje carinskog terminala.");
                    }
                    Simulacija.carinskiTerminalZaKamione.setSlobodan(true);
                    prosaoCarinskiTerminal = true;
                }
            }
        }
    }


}
