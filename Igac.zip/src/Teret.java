import java.util.Random;

public class Teret {
    private double stvarnaMasaTereta;

    public double getStvarnaMasaTereta() {
        return stvarnaMasaTereta;
    }

    public void setStvarnaMasaTereta(double stvarnaMasaTereta) {
        this.stvarnaMasaTereta = stvarnaMasaTereta;
    }

    public Teret(double stvarnaMasaTereta)
    {
        this.stvarnaMasaTereta=stvarnaMasaTereta;
    }
}
