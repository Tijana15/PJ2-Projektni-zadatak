public class Vozac extends Osoba
{
    private boolean imaKofer;
    public Vozac()
    {
        super();
        imaKofer=false;
    }

    public boolean imaLiKofer() {
        return imaKofer;
    }
}
