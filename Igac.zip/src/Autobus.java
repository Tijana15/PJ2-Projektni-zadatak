import java.util.*;

public class Autobus extends Vozilo implements AutobusInterface
{
    private TeretniProstor teretniProstor;
    public static final int MAX_BROJ_PUTNIKA_AUTOBUSA=52;
    public Autobus()
    {
        super(new Random().nextInt(MAX_BROJ_PUTNIKA_AUTOBUSA) + 1);
        teretniProstor=new TeretniProstor();
        for (int i = 0; i < getPutnici().size(); i++)
        {
            if(getPutnici().get(i).ImaLiKofer())
            {
                teretniProstor.dodajKoferUTeretniProstor(getPutnici().get(i).kofer);
            }
        }

    }

}
